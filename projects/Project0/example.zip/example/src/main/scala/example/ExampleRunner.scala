package example

import Example._

@main def run(): Unit = {
  val n = 3
  val m = -1

  println("The sum of " + n + " and " + m + " is " + add(n, m))
}


