package example

import Example._
import scala.io.Source
import java.io.{BufferedWriter, File, FileWriter}

@main def run(): Unit = {
  val n = 3
  val m = -1

  val firstPart = Source.fromFile("results/results_part1").getLines.mkString
  var score = 0.0
  var status = "failed"
  if (add(n, m) == 2)
    score = 2.0
    status = "passed"
  else{
    println("Error when summing " + n + " and " + m + " using add(" + n + "," + m + ")")
    println("Expected result: " + 2)
    println("Student's result: " + add(n,m))
  }

  val file = File("results/results.json")
  val bw = BufferedWriter(FileWriter(file))
  bw.write(firstPart + score.toString() + ",\n")
  bw.write("\"max_score\": 2.0\n\"status\": " + status + "\n   },\n],\n}")
  bw.close()
}


